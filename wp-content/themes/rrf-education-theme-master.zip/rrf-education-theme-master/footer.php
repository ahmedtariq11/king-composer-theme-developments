						<div class="footer">
							<div class="row">
								<?php dynamic_sidebar('footer'); ?>
							</div>
						</div>

						<div class="copyright">&copy; Copyright text Lorem ipsum dolor sit amet, consectetur adipisicing elit.</div>
	    			</div>
	    		</div>
	    	</div>
	    </div>        
        

        <?php wp_footer(); ?>
    </body>
</html>