(function ($) {
	"use strict";

    jQuery(document).ready(function($){
        
        $("#nav").slicknav({
            allowParentLinks: true
        });

    });


    jQuery(window).load(function(){

        
    });

}(jQuery));	