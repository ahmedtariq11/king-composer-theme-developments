<?php  

/* Template Name: Amit */

?>
    <?php get_header(); ?>
            
  






 <?php  get_footer();?>


  