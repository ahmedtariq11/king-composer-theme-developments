



jQuery.noConflict();
jQuery(document).ready(function(){
    jQuery(".flexslider").flexslider({
      
        animation: "slide",
    });
});