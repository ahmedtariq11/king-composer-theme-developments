// inicializamos con la función de flexslider()
jQuery.noConflict();
jQuery(document).ready(function($) {
  jQuery('.flexslider').flexslider({
    animation: "slide"
  });
});



